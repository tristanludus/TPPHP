README

----------------------------------------------------------------------------

La page servant � se connecter s'appelle: connexion.php
C'est celle-ci qu'il faudras ouvrir pour se connecter au site et ensuite acc�der aux autre pages.

L'utilisateur principal de connexion est: darkkevin
Et le mot de passe associ� � ce nom d'utilisateur est: bobo

----------------------------------------------------------------------------

Le menu principal (la deuxi�me page sur laquelle on tombe en se connectant) a �t� inclus
dans toutes les pages du site.
Cela nous �vite de mettre un bouton "retour � l'accueil" ou de devoir retourn� en arri�re

----------------------------------------------------------------------------

Le site comprend:
-Connexion
-Menu
-Affichage (produit,facture,client)
-Ajout (produit,facture,client)
-Suppression (produit,facture,client sur la m�me page)

----------------------------------------------------------------------------

L'impression et le syst�me update ne sont pas pr�sent, car je n'ai pas compris le fonctionnement
et tout essai �tait disfonctionnel.