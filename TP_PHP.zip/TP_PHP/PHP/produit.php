<link rel="stylesheet" href="style.css"> 
<?php include('menu.php'); ?>
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}
	
	$reponse=$bdd->query('SELECT Designation,PrixUnit,NumProduit FROM produit');

	while ($donnees=$reponse->fetch())
            {
            ?>
            <form method="post" action="" class="cat">

				<h3>Produit : <?php echo $donnees['Designation'];?> </h3>
				<h3>Prix : <?php echo $donnees['PrixUnit'];?> €</h3>
				<h3>Produit n°: <?php echo $donnees['NumProduit'];?> </h3>

			</form>
			</br>
            <?php
            }
	
	$reponse->closeCursor();
	
?>