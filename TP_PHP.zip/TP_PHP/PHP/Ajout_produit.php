<?php include('menu.php'); ?>

<!doctype html>	
<html lang="fr">
<head>
<link rel="stylesheet" type="text/css" media="screen" href="style.css" /> 
	<meta charset="utf-8">
	<title>Ajout</title>
</head>
<br>

<body>

						<center><h3 class="titre">Ajout d'un Produit </h3>
						<br/>
						<br/>
						<div>
							<form action="Ajout_produit.php" method="POST">
								<label for="Designation">DESIGNATION : <br/></label><br/><input type="text" name="Designation" required /><br/><br/>
								<label for="Prixunit">PRIX : </label><br/><input type="number" name="Prixunit" required/><br/><br/>
								<input type="submit" value="Valider" />
							</form>
						</div></center>
				
</body>

<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}

	if (isset($_POST['Designation']) and
	isset($_POST['Prixunit']) and
	!empty($_POST['Designation']) and
	!empty($_POST['Prixunit']))
	{
		//preparation de la requete
		$req = $bdd->prepare('INSERT INTO produit(Designation,PrixUnit) VALUES (:Designation,:Prixunit)');
		$req->execute(array(
		//''=>$_POST[''],
		'Designation'=>$_POST['Designation'],
		'Prixunit'=>$_POST['Prixunit']
		));
							
		echo "Votre requête a été ajouter à la base.";
							
		$req->closeCursor();
					
	}
?>