<link rel="stylesheet" href="style.css"> 
<?php include('menu.php'); ?>
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}
	
	$reponse=$bdd->query('SELECT NumFacture,DateFacture,NumClient FROM facture');

	while ($donnees=$reponse->fetch())
            {
            ?>
            <form method="post" action="" class="cat">

				<h3>Facture n°: <?php echo $donnees['NumFacture'];?> </h3>
				<h3>Date: <?php echo $donnees['DateFacture'];?> </h3>
				<h3>Client n°: <?php echo $donnees['NumClient'];?></h3>

			</form>
			</br>
            <?php
            }
	
	$reponse->closeCursor();
?>