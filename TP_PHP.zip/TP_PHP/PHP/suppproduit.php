<?php
try {
   $bdd = new PDO('mysql:host=localhost;dbname=facture;charset=utf8', 'root', '');
  } catch (Exception $e) {
   die('erreur : ' . $e -> getMessage());
  }
if (isset($_GET['NumProduit']) && !empty($_GET['NumProduit'])) {
 $NumProduit = $_GET['NumProduit'];
 $sql = "DELETE FROM `produit` WHERE `produit`.`NumProduit` = :NumProduit";
 $q = array('NumProduit' => $NumProduit);
 $req = $bdd -> prepare($sql);
 $req -> execute($q);
 $req->closeCursor();
 header('Location: profil.php');
}else{
	echo "pas bon";
}
?>