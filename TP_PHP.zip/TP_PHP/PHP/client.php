<link rel="stylesheet" href="style.css"> 
<?php include('menu.php'); ?>
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}
	
	session_start();		
	
	$reponse = $bdd->query('SELECT * FROM client ORDER BY VILLE ASC');
	
	while ($donnees = $reponse->fetch()){
	?>
	<form method="post" action="" class="cat">

		<h3>Nom : <?php echo $donnees['Nom'];?> </h3>
		<h3>Prenom : <?php echo $donnees['Prenom'];?> </h3>
		<h3>Adresse : <?php echo $donnees['Adresse'];?> </h3>
		<h3>Ville : <?php echo $donnees['Ville'];?> </h3>
		<h3>CP : <?php echo $donnees['CodePostal'];?> </h3>
		<h3>Pays : <?php echo $donnees['Pays'];?> </h3>

	</form>
	</br>


	
	
	<?php
	
	}

	$reponse->closeCursor();
?>