<!DOCTYPE html>
<html lang='fr'>
<head>
	<meta charset="utf-8">
	<title>Espace Personnel</title>
	<link rel="stylesheet" href="style.css"> 
</head>

<body>
	
	<center><h1>Veuillez vous connecter</h1></center>

	<form action="#" method="POST">  
			<p>
				<center><label for="Utilisateur">Nom d'utilisateur : </label><input type="text" name="Utilisateur" /></center>
				<br/>
				<br/>
				<center><label for="MDP">Mot de passe : </label><input type="password" name="MDP" /></center>
				<br/>
				<br/>
				<br/>
				<center><input type="submit" value="Connexion" /></center>
			</p>
	</form>

</body>
</html>

<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}

		if (isset($_POST['Utilisateur'], $_POST['MDP'])){

		$Utilisateur = htmlspecialchars($_POST['Utilisateur']);

		$htmlmdp = htmlspecialchars($_POST['MDP']);

	   		$req = $bdd->prepare("SELECT MDP FROM client WHERE Utilisateur = ?");
	   		$req -> execute(array($Utilisateur));

	   	 	while ($donnees = $req->fetch()){

	   			password_verify($htmlmdp, $donnees['MDP']);
	   		    {
					header('Location: menu.php');
	    		}
	    	}

	    $req->closeCursor();
		}
?>