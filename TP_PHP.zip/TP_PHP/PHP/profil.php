<link rel="stylesheet" type="text/css" media="screen" href="styleprofil.css" />
<body>
<?php include('menu.php'); ?>
<div class="départage" >
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}

	session_start();		
	
	$reponse = $bdd->query('SELECT * FROM client ORDER BY Utilisateur ASC');
	
	while ($donnees = $reponse->fetch())
	{
	echo "<hr /><div><a href='suppclient2.php?Utilisateur=" . $donnees['Utilisateur'] . "'><< SUPPRIMER CE LIEN >></a><p>";
	echo "<b>Nom :</b> " . $donnees['Nom'] . "<br />";
	echo "<b>Prénom :</b>" . $donnees['Prenom'] . "<br />";
	echo "<b>Adresse :</b> " . $donnees['Adresse'] . "<br />";
	echo "<b>Ville :</b> " . $donnees['Ville'] . "<br />";
	echo "<b>CodePostal :</b> " . $donnees['CodePostal'] . "<br />";
	echo "<b>Pays :</b> " . $donnees['Pays'] . "<br />";
	echo "</p></div><hr />";
	}

	$reponse->closeCursor();
	
?>
</div>
<div class="espace" ></div>
<div class="départage" >
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}
	
	$reponse = $bdd->query('SELECT * FROM produit ORDER BY NumProduit ASC');
	
	while ($donnees = $reponse->fetch())
	{
	echo "<hr /><div><a href='suppproduit.php?NumProduit=" . $donnees['NumProduit'] . "'><< SUPPRIMER CE LIEN >></a><p>";
	echo "<b>Designation :</b> " . $donnees['Designation'] . "<br />";
	echo "<b>Prix :</b>" . $donnees['PrixUnit'] . " €<br />";
	echo "</p></div><hr />";
	}

	$reponse->closeCursor();
	
?>
</div>
<div class="départage" >
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}

			
	
	$reponse = $bdd->query('SELECT sum(PrixUnit) AS somme FROM produit');
	
	while ($donnees = $reponse->fetch()){
	?>
		
	<hr/><h3>Total : <?php echo $donnees['somme'];?> € </h3><hr/>
	
	<?php
	}

	$reponse->closeCursor();
	
?>
</div>
<div class="espace" ></div>
<div class="départage" >
<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}

	$reponse = $bdd->query('SELECT * FROM facture ORDER BY NumFacture ASC');
	
	while ($donnees = $reponse->fetch())
	{
	echo "<hr /><div><a href='suppfacture.php?NumFacture=" . $donnees['NumFacture'] . "'><< SUPPRIMER CE LIEN >></a><p>";
	echo "<b>Date de la facture :</b> " . $donnees['DateFacture'] . "<br />";
	echo "<b>Numéro du client appartenant à la facture : </b>" . $donnees['NumClient'] . "<br />";
	echo "</p></div><hr />";
	}

	$reponse->closeCursor();
	
?>
</div>
</body>