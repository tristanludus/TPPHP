<link rel="stylesheet" href="style.css"> 
<form method="post" action="">

	<h1 class="ombre" ><center>Bienvenue</center></h1>
	<center><a href="produit.php" target=""><input type="button" value="Produit"></a>
	<a href="facture.php" target=""><input type="button" value="facture"></a>
	<a href="client.php" target=""><input type="button" value="client"></a>
	<a href="Ajout_produit.php" target=""><input type="button" value="Ajouter un produit"></a>
	<a href="Ajout_facture.php" target=""><input type="button" value="Ajouter une facture"></a>
	<a href="Ajout_client.php" target=""><input type="button" value="Ajouter un client"></a>
	<a href="profil.php" target=""><input type="button" value="Supprimer des éléments"></a></center>
	
	</form>
