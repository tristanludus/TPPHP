<?php include('menu.php'); ?>

<!doctype html>	
<html lang="fr">
<head>
<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
	<meta charset="utf-8">
	<title>Ajout</title>
</head>
<br>

<body>

						<center><h3 class="titre">Ajout d'un profil client</h3>
						<br/>
						<br/>
						<div>
							<form action="Ajout_client.php" method="POST">
								<label for="Utilisateur">UTILISATEUR : <br/></label><br/><input type="text" name="Utilisateur" required /><br/><br/>
								<label for="MDP">MOT DE PASSE : </label><br/><input type="text" name="MDP" required/><br/><br/>
								<label for="Nom">NOM : </label><br/><input type="text" name="Nom" required/><br/><br/>
								<label for="Prenom">PRENOM : </label><br/><input type="text" name="Prenom" required/><br/><br/>
								<label for="Adresse">ADRESSE : </label><br/><input type="text" name="Adresse" required/><br/><br/>
								<label for="Ville">VILLE : </label><br/><input type="text" name="Ville" required/><br/><br/>
								<label for="CodePostal">CODE POSTAL : </label><br/><input type="number" name="CodePostal" required/><br/><br/>
								<label for="Pays">PAYS : </label><br/><input type="text" name="Pays" required/><br/><br/>
								<input type="submit" value="Valider" />
							</form>
						</div></center>
				
</body>
<?php

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}
catch (Exception $e)
{
	die('Erreur : ' . $e->getMessage());
}

	if (isset($_POST['Utilisateur']) and
	isset($_POST['MDP']) and
	isset($_POST['Nom']) and
	isset($_POST['Prenom']) and
	isset($_POST['Adresse']) and
	isset($_POST['Ville']) and
	isset($_POST['CodePostal']) and
	isset($_POST['Pays']) and
	!empty($_POST['Utilisateur']) and
	!empty($_POST['MDP']) and
	!empty($_POST['Nom']) and
	!empty($_POST['Prenom']) and
	!empty($_POST['Adresse']) and
	!empty($_POST['Ville']) and
	!empty($_POST['CodePostal']) and
	!empty($_POST['Pays']))
	{
		//preparation de la requete
		$req = $bdd->prepare('INSERT INTO client(Utilisateur,MDP,Nom,Prenom,Adresse,Ville,CodePostal,Pays) VALUES (:Utilisateur,:MDP,:Nom,:Prenom,:Adresse,:Ville,:CodePostal,:Pays)');
		$req->execute(array(
		//''=>$_POST[''],
		'Utilisateur'=>$_POST['Utilisateur'],
		'MDP'=>$_POST['MDP'],
		'Nom'=>$_POST['Nom'],
		'Prenom'=>$_POST['Prenom'],
		'Adresse'=>$_POST['Adresse'],
		'Ville'=>$_POST['Ville'],
		'CodePostal'=>$_POST['CodePostal'],
		'Pays'=>$_POST['Pays']
		));
							
		echo "Votre requête a été ajouter à la base.";
							
		$req->closeCursor();
					
	}

?>