<?php include('menu.php'); ?>

<!doctype html>	
<html lang="fr">
<head>
<link rel="stylesheet" type="text/css" media="screen" href="style.css" /> 
	<meta charset="utf-8">
	<title>Ajout</title>
</head>
<br>

<body>

						<center><h3 class="titre">Ajout d'une facture </h3>
						<br/>
						<br/>
						<div>
							<form action="Ajout_facture.php" method="POST">
								<label for="DateFacture">DATE DE LA FACTURE : <br/></label><br/><input type="date" name="DateFacture" required /><br/><br/>
								<label for="NumClient">VOTRE NUMERO DE CLIENT : </label><br/><input type="number" name="NumClient" required/><br/><br/>
								<input type="submit" value="Valider" />
							</form>
						</div></center>
				
</body>

<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=facture', 'root', '');
	}
	catch (Exception $e)
	{
	        die('Erreur : ' . $e->getMessage());
	}
	
	if (isset($_POST['DateFacture']) and
	isset($_POST['NumClient']) and
	!empty($_POST['DateFacture']) and
	!empty($_POST['NumClient']))
	{
		//preparation de la requete
		$req = $bdd->prepare('INSERT INTO facture(DateFacture,NumClient) VALUES (:DateFacture,:NumClient)');
		$req->execute(array(
		//''=>$_POST[''],
		'DateFacture'=>$_POST['DateFacture'],
		'NumClient'=>$_POST['NumClient']
		));
							
		echo "Votre requête a été ajouter à la base.";
							
		$req->closeCursor();
					
	}
	
?>