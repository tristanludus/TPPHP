<?php
try {
   $bdd = new PDO('mysql:host=localhost;dbname=facture;charset=utf8', 'root', '');
  } catch (Exception $e) {
   die('erreur : ' . $e -> getMessage());
  }
if (isset($_GET['Utilisateur']) && !empty($_GET['Utilisateur'])) {
 $Utilisateur = $_GET['Utilisateur'];
 $sql = "DELETE FROM `client` WHERE `client`.`Utilisateur` = :Utilisateur";
 $q = array('Utilisateur' => $Utilisateur);
 $req = $bdd -> prepare($sql);
 $req -> execute($q);
 $req->closeCursor();
 header('Location: profil.php');
}else{
	echo "pas bon";
}
?>